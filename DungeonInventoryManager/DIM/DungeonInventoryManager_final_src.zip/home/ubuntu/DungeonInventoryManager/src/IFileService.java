import java.util.List;

public interface IFileService {
    void writeItemsToFile(List<Item> items, String filename);
    List<Item> readItemsFromFile(String filename);
}

